const AWS = require('aws-sdk');
const dynamoDB = new AWS.DynamoDB.DocumentClient();

module.exports.createOrder = async (event) => {
  const { product, quantity } = JSON.parse(event.body);

  const params = {
    TableName: 'Orders',
    Item: {
      id: Date.now().toString(),
      product,
      quantity,
    },
  };

  try {
    await dynamoDB.put(params).promise();
    return {
      statusCode: 200,
      body: JSON.stringify({ message: 'Order created successfully!' }),
    };
  } catch (error) {
    console.error(error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: 'Error creating order' }),
    };
  }
};

module.exports.getOrders = async (event) => {
  const params = {
    TableName: 'Orders',
  };

  try {
    const result = await dynamoDB.scan(params).promise();
    return {
      statusCode: 200,
      body: JSON.stringify(result.Items),
    };
  } catch (error) {
    console.error(error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: 'Error fetching orders' }),
    };
  }
};
